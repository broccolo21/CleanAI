# Guida Utente - CleanAI

## Introduzione

Benvenuto in CleanAI, la piattaforma innovativa che utilizza l'intelligenza artificiale per ottimizzare la gestione delle operazioni di pulizia professionale. Questa guida ti aiuterà a comprendere tutte le funzionalità disponibili e come utilizzarle al meglio.

CleanAI è progettato per tre tipi di utenti:
- **Amministratori**: responsabili della gestione complessiva del sistema
- **Operatori**: personale di pulizia che esegue le attività
- **Clienti**: utenti finali che richiedono e monitorano i servizi di pulizia

## Accesso al Sistema

### Registrazione e Login

1. Apri l'applicazione CleanAI nel tuo browser o dispositivo mobile
2. Seleziona "Registrati" se sei un nuovo utente o "Accedi" se hai già un account
3. Inserisci le tue credenziali (email e password)
4. Per il primo accesso, completa il tuo profilo con le informazioni richieste

### Recupero Password

1. Nella schermata di login, seleziona "Password dimenticata"
2. Inserisci l'email associata al tuo account
3. Segui le istruzioni ricevute via email per reimpostare la password

## Dashboard Principale

La dashboard è il punto centrale di CleanAI, dove puoi visualizzare tutte le informazioni importanti a colpo d'occhio.

### Elementi della Dashboard

- **Statistiche Principali**: mostra il numero di attività completate, il punteggio medio di qualità e il numero di sensori attivi
- **Grafici di Andamento**: visualizza l'andamento delle attività e dei punteggi di qualità nel tempo
- **Attività Recenti**: elenco delle ultime attività create o aggiornate
- **Pannello Avvisi**: mostra notifiche importanti e allarmi dai sensori
- **Mappa Interattiva**: visualizza la posizione delle attività e dei sensori

### Personalizzazione della Dashboard

1. Seleziona l'icona "Impostazioni" nell'angolo superiore destro della dashboard
2. Scegli quali widget visualizzare e in quale ordine
3. Imposta il periodo di tempo predefinito per i grafici
4. Salva le tue preferenze

## Gestione delle Attività

### Visualizzazione delle Attività

1. Seleziona "Attività" dal menu principale
2. Utilizza i filtri per visualizzare le attività per stato, operatore, posizione o data
3. Seleziona la visualizzazione preferita: elenco, calendario o mappa

### Creazione di una Nuova Attività

1. Seleziona "Nuova Attività" dalla pagina delle attività
2. Compila il modulo con le informazioni richieste:
   - Titolo e descrizione
   - Posizione
   - Operatore assegnato
   - Data e ora pianificata
   - Priorità
   - Durata stimata
3. Seleziona "Salva" per creare l'attività

### Gestione dello Stato delle Attività

1. Seleziona un'attività dall'elenco
2. Utilizza i pulsanti di azione per:
   - Avviare l'attività (cambia lo stato in "In corso")
   - Completare l'attività
   - Annullare l'attività
   - Riassegnare l'attività a un altro operatore
3. Aggiungi note o commenti quando necessario

## Tutor Virtuale per Operatori

Il Tutor Virtuale è un assistente AI che guida gli operatori durante le attività di pulizia.

### Attivazione del Tutor Virtuale

1. Apri l'app mobile CleanAI sul tuo dispositivo
2. Seleziona l'attività che desideri iniziare
3. Premi il pulsante "Avvia Tutor Virtuale"
4. Collega il tuo smartwatch o auricolare Bluetooth se desideri ricevere istruzioni vocali

### Utilizzo del Tutor Virtuale

1. Il Tutor ti guiderà passo dopo passo attraverso le procedure di pulizia
2. Segui le istruzioni vocali e visive fornite
3. Conferma il completamento di ogni passaggio toccando lo schermo o dicendo "Completato"
4. Puoi chiedere ulteriori dettagli o chiarimenti in qualsiasi momento
5. Al termine, il Tutor ti chiederà di documentare il lavoro svolto

## Analisi Visiva della Pulizia

### Acquisizione delle Immagini

1. Seleziona "Analisi Visiva" dal menu principale o dall'attività specifica
2. Scegli "Prima della Pulizia" per acquisire l'immagine iniziale
3. Inquadra l'area da pulire e scatta la foto
4. Dopo aver completato la pulizia, seleziona "Dopo la Pulizia"
5. Inquadra la stessa area dalla stessa angolazione e scatta la seconda foto

### Analisi dei Risultati

1. Il sistema analizzerà automaticamente le immagini e mostrerà:
   - Punteggio di pulizia prima e dopo
   - Percentuale di miglioramento
   - Aree problematiche evidenziate
   - Valutazione complessiva della qualità
2. Puoi visualizzare i dettagli dell'analisi selezionando "Mostra Dettagli"
3. Salva il report o condividilo con i clienti selezionando "Salva" o "Condividi"

## Report e Analisi

### Generazione di Report

1. Seleziona "Report" dal menu principale
2. Scegli il tipo di report desiderato:
   - Report di attività
   - Report di qualità
   - Report di sensori
   - Report personalizzato
3. Imposta i parametri del report (periodo, posizione, operatori, ecc.)
4. Seleziona "Genera Report"

### Visualizzazione e Condivisione dei Report

1. I report generati vengono visualizzati in formato grafico e tabellare
2. Utilizza i filtri per analizzare specifici aspetti dei dati
3. Esporta il report in formato PDF, Excel o CSV selezionando "Esporta"
4. Condividi il report via email selezionando "Condividi"
5. Imposta report ricorrenti selezionando "Pianifica Report"

## Sistema di Notifiche

### Gestione delle Notifiche

1. Seleziona l'icona delle notifiche nella barra superiore
2. Visualizza tutte le notifiche ricevute
3. Seleziona una notifica per visualizzarne i dettagli
4. Segna le notifiche come lette selezionandole e premendo "Segna come letta"
5. Elimina le notifiche selezionandole e premendo "Elimina"

### Impostazioni delle Notifiche

1. Seleziona "Impostazioni" dal menu principale
2. Vai alla sezione "Notifiche"
3. Personalizza quali notifiche ricevere e come:
   - Email
   - Notifiche push
   - SMS
   - Notifiche in-app
4. Imposta la priorità e gli orari per ciascun tipo di notifica

## Integrazione IoT e Sensori

### Monitoraggio dei Sensori

1. Seleziona "Sensori" dal menu principale
2. Visualizza tutti i sensori attivi sulla mappa o in elenco
3. Seleziona un sensore per visualizzarne i dettagli:
   - Tipo di sensore
   - Posizione
   - Valore attuale
   - Storico dei valori
   - Stato della batteria

### Configurazione degli Allarmi

1. Seleziona un sensore dall'elenco
2. Vai alla sezione "Allarmi"
3. Imposta le soglie per gli allarmi:
   - Valore minimo
   - Valore massimo
   - Variazione rapida
4. Configura le azioni da intraprendere quando viene attivato un allarme:
   - Inviare notifica
   - Creare automaticamente un'attività
   - Avvisare specifici operatori

## Funzionalità Offline

CleanAI funziona anche senza connessione internet, sincronizzando i dati quando la connessione viene ripristinata.

### Utilizzo in Modalità Offline

1. L'app passerà automaticamente alla modalità offline quando non è disponibile una connessione
2. Continua a utilizzare l'app normalmente
3. I dati verranno salvati localmente sul dispositivo
4. Un'icona nella barra superiore indicherà che sei in modalità offline

### Sincronizzazione dei Dati

1. Quando la connessione internet viene ripristinata, l'app sincronizzerà automaticamente i dati
2. Puoi forzare la sincronizzazione manuale selezionando "Sincronizza" dal menu
3. In caso di conflitti di dati, ti verrà chiesto di risolverli

## Impostazioni Utente

### Profilo Utente

1. Seleziona il tuo nome utente nell'angolo superiore destro
2. Seleziona "Profilo" dal menu a discesa
3. Modifica le tue informazioni personali:
   - Nome e cognome
   - Email
   - Numero di telefono
   - Foto profilo
4. Seleziona "Salva" per confermare le modifiche

### Preferenze dell'Applicazione

1. Seleziona "Impostazioni" dal menu principale
2. Personalizza l'aspetto e il comportamento dell'app:
   - Tema (chiaro/scuro)
   - Lingua
   - Fuso orario
   - Formato data e ora
   - Notifiche
3. Seleziona "Salva" per confermare le modifiche

## Funzionalità per Amministratori

### Gestione Utenti

1. Seleziona "Amministrazione" dal menu principale
2. Vai alla sezione "Utenti"
3. Visualizza, crea, modifica o disattiva account utente
4. Assegna ruoli e permessi agli utenti

### Configurazione del Sistema

1. Seleziona "Amministrazione" dal menu principale
2. Vai alla sezione "Configurazione"
3. Personalizza le impostazioni globali del sistema:
   - Parametri di qualità
   - Integrazione con sistemi esterni
   - Pianificazione automatica
   - Backup dei dati

## Supporto e Assistenza

### Accesso alla Documentazione

1. Seleziona "Aiuto" dal menu principale
2. Sfoglia la documentazione per categoria
3. Utilizza la funzione di ricerca per trovare argomenti specifici

### Contattare il Supporto

1. Seleziona "Supporto" dal menu principale
2. Scegli il metodo di contatto preferito:
   - Chat dal vivo
   - Email
   - Telefono
3. Descrivi il problema o la domanda in dettaglio
4. Allega screenshot o file se necessario

## Consigli per l'Utilizzo Ottimale

1. **Aggiorna regolarmente l'app** per accedere alle ultime funzionalità e miglioramenti
2. **Utilizza i filtri** per trovare rapidamente le informazioni di cui hai bisogno
3. **Personalizza la dashboard** in base alle tue esigenze specifiche
4. **Documenta sempre con foto** prima e dopo per ottenere analisi accurate
5. **Configura le notifiche** per rimanere informato sugli eventi importanti
6. **Utilizza la modalità offline** quando lavori in aree con connessione limitata
7. **Esplora i report analitici** per identificare tendenze e opportunità di miglioramento

## Risoluzione dei Problemi Comuni

### L'app non si avvia o si blocca

1. Verifica la connessione internet
2. Riavvia l'app
3. Aggiorna l'app all'ultima versione
4. Riavvia il dispositivo
5. Se il problema persiste, contatta il supporto

### Problemi di sincronizzazione

1. Verifica la connessione internet
2. Prova a sincronizzare manualmente
3. Esci e accedi nuovamente all'app
4. Se il problema persiste, contatta il supporto

### Errori nell'analisi delle immagini

1. Assicurati che l'illuminazione sia adeguata
2. Scatta le foto dalla stessa angolazione
3. Evita riflessi e ombre eccessive
4. Riprova l'analisi
5. Se il problema persiste, contatta il supporto
