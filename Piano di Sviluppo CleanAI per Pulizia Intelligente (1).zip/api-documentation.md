# API Documentation - CleanAI

## Introduzione

Questa documentazione descrive le API RESTful e GraphQL disponibili per l'integrazione con il sistema CleanAI. Le API consentono di gestire attività di pulizia, utenti, analisi della qualità, notifiche e dati IoT.

## Autenticazione

Tutte le richieste API richiedono autenticazione tramite token JWT. Per ottenere un token, è necessario effettuare una richiesta di login.

### Ottenere un token

```
POST /api/auth/login
```

**Parametri di richiesta:**

```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Risposta:**

```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "123",
    "email": "user@example.com",
    "name": "Mario Rossi",
    "role": "operator"
  }
}
```

### Utilizzo del token

Includere il token in tutte le richieste API nel header `Authorization`:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## API RESTful

### Attività

#### Ottenere tutte le attività

```
GET /api/tasks
```

**Parametri di query opzionali:**

- `status`: Filtra per stato (pending, in_progress, completed)
- `assigned_to`: Filtra per operatore assegnato
- `location`: Filtra per posizione
- `limit`: Limita il numero di risultati
- `offset`: Offset per la paginazione

**Risposta:**

```json
{
  "tasks": [
    {
      "id": "1",
      "title": "Pulizia uffici piano 3",
      "description": "Pulizia completa degli uffici al piano 3",
      "status": "pending",
      "location": "Edificio A, Piano 3",
      "assigned_to": "operator_1",
      "scheduled_for": "2025-03-26T09:00:00Z",
      "created_at": "2025-03-25T10:00:00Z",
      "updated_at": "2025-03-25T10:00:00Z"
    },
    // ...
  ],
  "total": 42,
  "limit": 10,
  "offset": 0
}
```

#### Ottenere una singola attività

```
GET /api/tasks/:id
```

**Risposta:**

```json
{
  "id": "1",
  "title": "Pulizia uffici piano 3",
  "description": "Pulizia completa degli uffici al piano 3",
  "status": "pending",
  "location": "Edificio A, Piano 3",
  "assigned_to": "operator_1",
  "scheduled_for": "2025-03-26T09:00:00Z",
  "created_at": "2025-03-25T10:00:00Z",
  "updated_at": "2025-03-25T10:00:00Z",
  "notes": "",
  "priority": "medium",
  "estimated_duration": 120
}
```

#### Creare una nuova attività

```
POST /api/tasks
```

**Parametri di richiesta:**

```json
{
  "title": "Pulizia bagni",
  "description": "Pulizia completa dei bagni al piano 2",
  "status": "pending",
  "location": "Edificio B, Piano 2",
  "assigned_to": "operator_2",
  "scheduled_for": "2025-03-27T14:00:00Z",
  "priority": "high",
  "estimated_duration": 60
}
```

**Risposta:**

```json
{
  "id": "2",
  "title": "Pulizia bagni",
  "description": "Pulizia completa dei bagni al piano 2",
  "status": "pending",
  "location": "Edificio B, Piano 2",
  "assigned_to": "operator_2",
  "scheduled_for": "2025-03-27T14:00:00Z",
  "created_at": "2025-03-25T11:30:00Z",
  "updated_at": "2025-03-25T11:30:00Z",
  "notes": "",
  "priority": "high",
  "estimated_duration": 60
}
```

#### Aggiornare un'attività

```
PUT /api/tasks/:id
```

**Parametri di richiesta:**

```json
{
  "status": "in_progress",
  "notes": "Iniziata la pulizia"
}
```

**Risposta:**

```json
{
  "id": "2",
  "title": "Pulizia bagni",
  "description": "Pulizia completa dei bagni al piano 2",
  "status": "in_progress",
  "location": "Edificio B, Piano 2",
  "assigned_to": "operator_2",
  "scheduled_for": "2025-03-27T14:00:00Z",
  "created_at": "2025-03-25T11:30:00Z",
  "updated_at": "2025-03-25T12:15:00Z",
  "notes": "Iniziata la pulizia",
  "priority": "high",
  "estimated_duration": 60
}
```

#### Eliminare un'attività

```
DELETE /api/tasks/:id
```

**Risposta:**

```json
{
  "message": "Task deleted successfully"
}
```

### Utenti

#### Ottenere tutti gli utenti

```
GET /api/users
```

**Parametri di query opzionali:**

- `role`: Filtra per ruolo (admin, operator, client)
- `limit`: Limita il numero di risultati
- `offset`: Offset per la paginazione

**Risposta:**

```json
{
  "users": [
    {
      "id": "1",
      "name": "Mario Rossi",
      "email": "mario@example.com",
      "role": "operator",
      "created_at": "2025-01-15T10:00:00Z"
    },
    // ...
  ],
  "total": 25,
  "limit": 10,
  "offset": 0
}
```

#### Ottenere un singolo utente

```
GET /api/users/:id
```

**Risposta:**

```json
{
  "id": "1",
  "name": "Mario Rossi",
  "email": "mario@example.com",
  "role": "operator",
  "phone": "+39 123 456 7890",
  "created_at": "2025-01-15T10:00:00Z",
  "updated_at": "2025-03-10T14:30:00Z",
  "profile_image": "https://example.com/profiles/mario.jpg",
  "settings": {
    "notifications_enabled": true,
    "theme": "light"
  }
}
```

### Analisi della Qualità

#### Caricare un'immagine per l'analisi

```
POST /api/analysis/upload
```

**Parametri di richiesta:**
- Multipart form con campo `image`

**Risposta:**

```json
{
  "imageUrl": "https://storage.cleanai.app/images/analysis/before_123456.jpg",
  "uploadedAt": "2025-03-25T14:30:00Z"
}
```

#### Analizzare un'immagine

```
POST /api/analysis/analyze
```

**Parametri di richiesta:**

```json
{
  "imageUrl": "https://storage.cleanai.app/images/analysis/before_123456.jpg",
  "type": "before"
}
```

**Risposta:**

```json
{
  "analysis": {
    "dirt_detected": true,
    "cleanliness_score": 0.65,
    "detected_objects": [
      {
        "class": "dust",
        "confidence": 0.92,
        "box": [100, 150, 200, 250]
      },
      {
        "class": "stain",
        "confidence": 0.87,
        "box": [300, 350, 400, 450]
      }
    ]
  },
  "timestamp": "2025-03-25T14:32:00Z"
}
```

#### Confrontare immagini prima/dopo

```
POST /api/analysis/compare
```

**Parametri di richiesta:**

```json
{
  "beforeImageUrl": "https://storage.cleanai.app/images/analysis/before_123456.jpg",
  "afterImageUrl": "https://storage.cleanai.app/images/analysis/after_123456.jpg",
  "taskId": 123,
  "location": "Edificio A, Piano 3"
}
```

**Risposta:**

```json
{
  "reportId": "789",
  "report": {
    "before_analysis": {
      "dirt_detected": true,
      "cleanliness_score": 0.65,
      "detected_objects": [
        // ...
      ]
    },
    "after_analysis": {
      "dirt_detected": false,
      "cleanliness_score": 0.95,
      "detected_objects": []
    },
    "comparison": {
      "improvement_score": 0.3,
      "percentage_improvement": 46.15,
      "quality_rating": "excellent"
    },
    "timestamp": "2025-03-25T15:00:00Z"
  }
}
```

### Notifiche

#### Ottenere le notifiche dell'utente

```
GET /api/notifications
```

**Parametri di query opzionali:**

- `unread_only`: Se true, restituisce solo le notifiche non lette
- `limit`: Limita il numero di risultati
- `offset`: Offset per la paginazione

**Risposta:**

```json
{
  "notifications": [
    {
      "id": "1",
      "type": "task_update",
      "title": "Attività completata",
      "message": "L'attività #123 è stata completata con successo",
      "read": false,
      "created_at": "2025-03-25T13:00:00Z",
      "data": {
        "task_id": 123,
        "status": "completed"
      }
    },
    // ...
  ],
  "total": 15,
  "unread": 3,
  "limit": 10,
  "offset": 0
}
```

#### Segnare una notifica come letta

```
PUT /api/notifications/:id/read
```

**Risposta:**

```json
{
  "success": true,
  "notification": {
    "id": "1",
    "read": true,
    "updated_at": "2025-03-25T16:45:00Z"
  }
}
```

#### Inviare una notifica

```
POST /api/notifications/send
```

**Parametri di richiesta:**

```json
{
  "title": "Nuova attività assegnata",
  "message": "Ti è stata assegnata una nuova attività di pulizia",
  "recipientId": "operator_1",
  "type": "task_assignment",
  "data": {
    "task_id": 456,
    "scheduled_for": "2025-03-26T10:00:00Z"
  },
  "priority": "high"
}
```

**Risposta:**

```json
{
  "success": true,
  "notificationId": "2",
  "sent_at": "2025-03-25T17:00:00Z"
}
```

### Dati IoT

#### Ottenere i dati dei sensori

```
GET /api/iot/sensors
```

**Parametri di query opzionali:**

- `type`: Filtra per tipo di sensore (humidity, temperature, motion, air_quality, dirt_level)
- `location`: Filtra per posizione
- `from`: Data di inizio (ISO 8601)
- `to`: Data di fine (ISO 8601)
- `limit`: Limita il numero di risultati

**Risposta:**

```json
{
  "sensors": [
    {
      "id": "sensor_123",
      "type": "humidity",
      "location": "Edificio A, Piano 3",
      "value": 65.4,
      "unit": "%",
      "timestamp": "2025-03-25T16:30:00Z",
      "battery": 92,
      "status": "active"
    },
    // ...
  ],
  "total": 50
}
```

#### Ottenere lo storico dei dati di un sensore

```
GET /api/iot/sensors/:id/history
```

**Parametri di query opzionali:**

- `from`: Data di inizio (ISO 8601)
- `to`: Data di fine (ISO 8601)
- `interval`: Intervallo di aggregazione (hour, day, week)
- `limit`: Limita il numero di risultati

**Risposta:**

```json
{
  "sensor": {
    "id": "sensor_123",
    "type": "humidity",
    "location": "Edificio A, Piano 3"
  },
  "data": [
    {
      "timestamp": "2025-03-25T16:00:00Z",
      "value": 65.4,
      "unit": "%"
    },
    {
      "timestamp": "2025-03-25T15:00:00Z",
      "value": 64.2,
      "unit": "%"
    },
    // ...
  ],
  "stats": {
    "min": 60.1,
    "max": 68.7,
    "avg": 64.8
  }
}
```

## API GraphQL

CleanAI offre anche un'API GraphQL per query più flessibili e complesse. L'endpoint GraphQL è disponibile a:

```
POST /graphql
```

### Schema GraphQL

```graphql
type Task {
  id: ID!
  title: String!
  description: String
  status: TaskStatus!
  location: String!
  assignedTo: User
  scheduledFor: DateTime
  createdAt: DateTime!
  updatedAt: DateTime!
  notes: String
  priority: Priority!
  estimatedDuration: Int
  qualityScores: [QualityScore]
}

enum TaskStatus {
  PENDING
  IN_PROGRESS
  COMPLETED
  CANCELLED
}

enum Priority {
  LOW
  MEDIUM
  HIGH
}

type User {
  id: ID!
  name: String!
  email: String!
  role: UserRole!
  phone: String
  createdAt: DateTime!
  updatedAt: DateTime!
  profileImage: String
  settings: UserSettings
  assignedTasks: [Task]
}

enum UserRole {
  ADMIN
  OPERATOR
  CLIENT
}

type UserSettings {
  notificationsEnabled: Boolean!
  theme: String!
}

type QualityScore {
  id: ID!
  taskId: ID!
  score: Float!
  beforeImage: String
  afterImage: String
  improvement: Float
  timestamp: DateTime!
  location: String
  report: AnalysisReport
}

type AnalysisReport {
  id: ID!
  beforeAnalysis: Analysis!
  afterAnalysis: Analysis!
  comparison: Comparison!
  timestamp: DateTime!
}

type Analysis {
  dirtDetected: Boolean!
  cleanlinessScore: Float!
  detectedObjects: [DetectedObject]
}

type DetectedObject {
  class: String!
  confidence: Float!
  box: [Int!]!
}

type Comparison {
  improvementScore: Float!
  percentageImprovement: Float!
  qualityRating: String!
}

type Notification {
  id: ID!
  type: String!
  title: String!
  message: String!
  read: Boolean!
  createdAt: DateTime!
  data: JSON
  recipient: User!
  priority: String
}

type Sensor {
  id: ID!
  type: String!
  location: String!
  value: Float!
  unit: String!
  timestamp: DateTime!
  battery: Int!
  status: String!
  history(from: DateTime, to: DateTime, interval: String): [SensorData]
}

type SensorData {
  timestamp: DateTime!
  value: Float!
  unit: String!
}

type Query {
  tasks(status: TaskStatus, assignedTo: ID, location: String, limit: Int, offset: Int): [Task]
  task(id: ID!): Task
  users(role: UserRole, limit: Int, offset: Int): [User]
  user(id: ID!): User
  qualityScores(taskId: ID, limit: Int): [QualityScore]
  qualityScore(id: ID!): QualityScore
  notifications(unreadOnly: Boolean, limit: Int, offset: Int): [Notification]
  sensors(type: String, location: String, limit: Int): [Sensor]
  sensor(id: ID!): Sensor
  dashboard: DashboardData
}

type DashboardData {
  completedTasks: Int!
  averageQualityScore: Float!
  activeSensors: Int!
  recentTasks: [Task]
  qualityTrend: [QualityTrend]
}

type QualityTrend {
  date: String!
  score: Float!
}

type Mutation {
  createTask(input: TaskInput!): Task
  updateTask(id: ID!, input: TaskUpdateInput!): Task
  deleteTask(id: ID!): Boolean
  markNotificationAsRead(id: ID!): Notification
  sendNotification(input: NotificationInput!): Notification
  uploadImage(file: Upload!): UploadResult
  analyzeImage(imageUrl: String!, type: String!): Analysis
  compareImages(beforeImageUrl: String!, afterImageUrl: String!, taskId: ID, location: String): AnalysisReport
}

input TaskInput {
  title: String!
  description: String
  status: TaskStatus!
  location: String!
  assignedTo: ID
  scheduledFor: DateTime
  priority: Priority!
  estimatedDuration: Int
}

input TaskUpdateInput {
  title: String
  description: String
  status: TaskStatus
  location: String
  assignedTo: ID
  scheduledFor: DateTime
  notes: String
  priority: Priority
  estimatedDuration: Int
}

input NotificationInput {
  title: String!
  message: String!
  recipientId: ID!
  type: String!
  data: JSON
  priority: String
}

type UploadResult {
  imageUrl: String!
  uploadedAt: DateTime!
}

scalar DateTime
scalar JSON
scalar Upload
```

### Esempi di Query GraphQL

#### Ottenere attività con operatore assegnato e punteggi di qualità

```graphql
query {
  tasks(status: IN_PROGRESS, limit: 5) {
    id
    title
    location
    status
    assignedTo {
      id
      name
      email
    }
    qualityScores {
      score
      timestamp
    }
  }
}
```

#### Ottenere dati dashboard completi

```graphql
query {
  dashboard {
    completedTasks
    averageQualityScore
    activeSensors
    recentTasks {
      id
      title
      status
      location
      scheduledFor
    }
    qualityTrend {
      date
      score
    }
  }
}
```

#### Creare una nuova attività

```graphql
mutation {
  createTask(input: {
    title: "Pulizia sala riunioni",
    description: "Pulizia completa della sala riunioni principale",
    status: PENDING,
    location: "Edificio A, Piano 1, Sala 101",
    assignedTo: "operator_3",
    scheduledFor: "2025-03-28T09:00:00Z",
    priority: HIGH,
    estimatedDuration: 90
  }) {
    id
    title
    status
    createdAt
  }
}
```

## Webhook

CleanAI supporta webhook per ricevere notifiche in tempo reale su eventi specifici.

### Registrare un webhook

```
POST /api/webhooks/register
```

**Parametri di richiesta:**

```json
{
  "url": "https://your-server.com/webhook",
  "events": ["task.created", "task.updated", "quality_score.created"],
  "secret": "your_webhook_secret"
}
```

**Risposta:**

```json
{
  "id": "webhook_123",
  "url": "https://your-server.com/webhook",
  "events": ["task.created", "task.updated", "quality_score.created"],
  "created_at": "2025-03-25T17:30:00Z"
}
```

### Eventi supportati

- `task.created`: Quando viene creata una nuova attività
- `task.updated`: Quando un'attività viene aggiornata
- `task.completed`: Quando un'attività viene completata
- `quality_score.created`: Quando viene creato un nuovo punteggio di qualità
- `sensor.alert`: Quando un sensore genera un allarme
- `user.created`: Quando viene creato un nuovo utente

### Formato dei payload webhook

```json
{
  "event": "task.updated",
  "timestamp": "2025-03-25T18:00:00Z",
  "data": {
    "id": "123",
    "title": "Pulizia uffici piano 3",
    "status": "completed",
    "updated_at": "2025-03-25T18:00:00Z"
  }
}
```

## Limiti di Utilizzo

- Rate limit: 100 richieste al minuto per utente
- Dimensione massima upload immagini: 10 MB
- Numero massimo di webhook: 10 per account

## Codici di Errore

- `400`: Bad Request - La richiesta contiene parametri non validi
- `401`: Unauthorized - Token di autenticazione mancante o non valido
- `403`: Forbidden - L'utente non ha i permessi necessari
- `404`: Not Found - La risorsa richiesta non esiste
- `429`: Too Many Requests - Superato il limite di richieste
- `500`: Internal Server Error - Errore interno del server

## Versioning

L'API è attualmente alla versione 1.0. Le versioni future saranno accessibili tramite prefisso nell'URL (es. `/v2/api/tasks`).

## Supporto

Per assistenza tecnica, contattare support@cleanai.app o visitare la documentazione completa su https://docs.cleanai.app.
