// File: backend/tests/controllers.test.js
const request = require('supertest');
const { app } = require('../src/main');
const { supabase } = require('../src/supabase-config');

// Mock di Supabase
jest.mock('../src/supabase-config', () => ({
  supabase: {
    from: jest.fn().mockReturnThis(),
    select: jest.fn().mockReturnThis(),
    insert: jest.fn().mockReturnThis(),
    update: jest.fn().mockReturnThis(),
    delete: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    single: jest.fn(),
    then: jest.fn(),
    catch: jest.fn()
  }
}));

describe('API Controllers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Tasks API', () => {
    test('GET /api/tasks dovrebbe restituire la lista delle attività', async () => {
      // Mock della risposta di Supabase
      const mockTasks = [
        { id: 1, title: 'Pulizia uffici', status: 'pending', assigned_to: 'user1' },
        { id: 2, title: 'Pulizia bagni', status: 'completed', assigned_to: 'user2' }
      ];
      
      supabase.select.mockImplementation(() => ({
        then: (callback) => callback({ data: mockTasks, error: null })
      }));

      const response = await request(app).get('/api/tasks');
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockTasks);
      expect(supabase.from).toHaveBeenCalledWith('tasks');
      expect(supabase.select).toHaveBeenCalled();
    });

    test('POST /api/tasks dovrebbe creare una nuova attività', async () => {
      const newTask = {
        title: 'Nuova pulizia',
        description: 'Descrizione attività',
        status: 'pending',
        assigned_to: 'user1'
      };
      
      const mockResponse = {
        data: { id: 3, ...newTask },
        error: null
      };
      
      supabase.insert.mockImplementation(() => ({
        then: (callback) => callback(mockResponse)
      }));

      const response = await request(app)
        .post('/api/tasks')
        .send(newTask);
      
      expect(response.status).toBe(201);
      expect(response.body).toEqual(mockResponse.data);
      expect(supabase.from).toHaveBeenCalledWith('tasks');
      expect(supabase.insert).toHaveBeenCalledWith(newTask);
    });

    test('PUT /api/tasks/:id dovrebbe aggiornare un\'attività esistente', async () => {
      const taskId = 1;
      const updatedTask = {
        status: 'completed'
      };
      
      const mockResponse = {
        data: { id: taskId, title: 'Pulizia uffici', ...updatedTask },
        error: null
      };
      
      supabase.update.mockImplementation(() => ({
        eq: () => ({
          then: (callback) => callback(mockResponse)
        })
      }));

      const response = await request(app)
        .put(`/api/tasks/${taskId}`)
        .send(updatedTask);
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockResponse.data);
      expect(supabase.from).toHaveBeenCalledWith('tasks');
      expect(supabase.update).toHaveBeenCalledWith(updatedTask);
      expect(supabase.eq).toHaveBeenCalledWith('id', taskId.toString());
    });

    test('DELETE /api/tasks/:id dovrebbe eliminare un\'attività', async () => {
      const taskId = 1;
      
      const mockResponse = {
        data: { id: taskId },
        error: null
      };
      
      supabase.delete.mockImplementation(() => ({
        eq: () => ({
          then: (callback) => callback(mockResponse)
        })
      }));

      const response = await request(app)
        .delete(`/api/tasks/${taskId}`);
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual({ message: 'Task deleted successfully' });
      expect(supabase.from).toHaveBeenCalledWith('tasks');
      expect(supabase.delete).toHaveBeenCalled();
      expect(supabase.eq).toHaveBeenCalledWith('id', taskId.toString());
    });
  });

  describe('Users API', () => {
    test('GET /api/users dovrebbe restituire la lista degli utenti', async () => {
      const mockUsers = [
        { id: 1, name: 'Mario Rossi', role: 'operator' },
        { id: 2, name: 'Giuseppe Verdi', role: 'client' }
      ];
      
      supabase.select.mockImplementation(() => ({
        then: (callback) => callback({ data: mockUsers, error: null })
      }));

      const response = await request(app).get('/api/users');
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUsers);
      expect(supabase.from).toHaveBeenCalledWith('users');
      expect(supabase.select).toHaveBeenCalled();
    });

    test('GET /api/users/:id dovrebbe restituire un singolo utente', async () => {
      const userId = 1;
      const mockUser = { id: userId, name: 'Mario Rossi', role: 'operator' };
      
      supabase.select.mockImplementation(() => ({
        eq: () => ({
          single: () => ({
            then: (callback) => callback({ data: mockUser, error: null })
          })
        })
      }));

      const response = await request(app).get(`/api/users/${userId}`);
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUser);
      expect(supabase.from).toHaveBeenCalledWith('users');
      expect(supabase.select).toHaveBeenCalled();
      expect(supabase.eq).toHaveBeenCalledWith('id', userId.toString());
      expect(supabase.single).toHaveBeenCalled();
    });
  });

  describe('Analytics API', () => {
    test('GET /api/analytics/quality-scores dovrebbe restituire i punteggi di qualità', async () => {
      const mockScores = [
        { id: 1, task_id: 1, score: 0.92, timestamp: '2025-03-20T10:00:00Z' },
        { id: 2, task_id: 2, score: 0.85, timestamp: '2025-03-21T11:30:00Z' }
      ];
      
      supabase.select.mockImplementation(() => ({
        then: (callback) => callback({ data: mockScores, error: null })
      }));

      const response = await request(app).get('/api/analytics/quality-scores');
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockScores);
      expect(supabase.from).toHaveBeenCalledWith('quality_scores');
      expect(supabase.select).toHaveBeenCalled();
    });
  });

  describe('Error Handling', () => {
    test('Dovrebbe gestire gli errori di Supabase', async () => {
      const mockError = { message: 'Database error' };
      
      supabase.select.mockImplementation(() => ({
        then: (callback) => callback({ data: null, error: mockError })
      }));

      const response = await request(app).get('/api/tasks');
      
      expect(response.status).toBe(500);
      expect(response.body).toEqual({ error: mockError.message });
    });
  });
});
