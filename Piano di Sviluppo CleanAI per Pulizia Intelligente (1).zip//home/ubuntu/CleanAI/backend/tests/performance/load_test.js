// File: backend/tests/performance/load_test.js
const autocannon = require('autocannon');
const { promisify } = require('util');
const fs = require('fs');
const path = require('path');

// Converti autocannon in una versione che supporta le promesse
const autocannonAsync = promisify(autocannon);

// Configurazione del test
const config = {
  url: 'http://localhost:3000',
  connections: 100,
  duration: 30,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer test-token' // Token di test
  },
  requests: [
    {
      method: 'GET',
      path: '/api/tasks',
      onResponse: (status, body, context) => {
        // Registra le risposte per analisi
        context.responses = context.responses || [];
        context.responses.push({ status, body: body.slice(0, 100) + '...' });
      }
    },
    {
      method: 'GET',
      path: '/api/users',
      onResponse: (status, body, context) => {
        context.responses = context.responses || [];
        context.responses.push({ status, body: body.slice(0, 100) + '...' });
      }
    },
    {
      method: 'GET',
      path: '/api/analytics/quality-scores',
      onResponse: (status, body, context) => {
        context.responses = context.responses || [];
        context.responses.push({ status, body: body.slice(0, 100) + '...' });
      }
    }
  ]
};

// Funzione per eseguire il test
async function runLoadTest() {
  console.log('Avvio test di carico...');
  console.log(`Connessioni: ${config.connections}, Durata: ${config.duration}s`);
  
  try {
    const results = await autocannonAsync(config);
    
    // Analizza i risultati
    console.log('Test completato!');
    console.log('Risultati:');
    console.log(`Richieste totali: ${results.requests.total}`);
    console.log(`Richieste al secondo: ${results.requests.average}`);
    console.log(`Latenza media: ${results.latency.average} ms`);
    console.log(`Latenza massima: ${results.latency.max} ms`);
    console.log(`Throughput: ${results.throughput.average} bytes/sec`);
    
    // Salva i risultati in un file
    const reportDir = path.join(__dirname, 'reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const reportPath = path.join(reportDir, `load-test-report-${timestamp}.json`);
    
    fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
    console.log(`Report salvato in: ${reportPath}`);
    
    // Verifica se il test ha superato le soglie di performance
    const thresholds = {
      requestsPerSecond: 500,
      averageLatency: 100,
      maxLatency: 500
    };
    
    const passed = 
      results.requests.average >= thresholds.requestsPerSecond &&
      results.latency.average <= thresholds.averageLatency &&
      results.latency.max <= thresholds.maxLatency;
    
    if (passed) {
      console.log('✅ Test di performance superato!');
    } else {
      console.log('❌ Test di performance fallito!');
      console.log('Soglie:');
      console.log(`- Richieste al secondo: ${thresholds.requestsPerSecond}`);
      console.log(`- Latenza media: ${thresholds.averageLatency} ms`);
      console.log(`- Latenza massima: ${thresholds.maxLatency} ms`);
    }
    
    return { results, passed };
  } catch (error) {
    console.error('Errore durante il test di carico:', error);
    throw error;
  }
}

// Esegui il test se il file è eseguito direttamente
if (require.main === module) {
  runLoadTest()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
} else {
  module.exports = { runLoadTest };
}
