// File: backend/tests/auth.test.js
const jwt = require('jsonwebtoken');
const { verifyToken, generateToken, checkRole } = require('../src/auth');

// Mock di jsonwebtoken
jest.mock('jsonwebtoken');

describe('Auth Module', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('generateToken', () => {
    test('dovrebbe generare un token JWT valido', () => {
      // Arrange
      const user = { id: 1, email: 'test@example.com', role: 'operator' };
      const mockToken = 'mock-jwt-token';
      jwt.sign.mockReturnValue(mockToken);

      // Act
      const token = generateToken(user);

      // Assert
      expect(token).toBe(mockToken);
      expect(jwt.sign).toHaveBeenCalledWith(
        { id: user.id, email: user.email, role: user.role },
        expect.any(String),
        { expiresIn: '24h' }
      );
    });
  });

  describe('verifyToken', () => {
    test('dovrebbe verificare un token valido', () => {
      // Arrange
      const req = {
        headers: {
          authorization: 'Bearer valid-token'
        }
      };
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      const next = jest.fn();
      
      const decodedToken = { id: 1, email: 'test@example.com', role: 'operator' };
      jwt.verify.mockImplementation((token, secret, callback) => {
        callback(null, decodedToken);
      });

      // Act
      verifyToken(req, res, next);

      // Assert
      expect(jwt.verify).toHaveBeenCalled();
      expect(req.user).toEqual(decodedToken);
      expect(next).toHaveBeenCalled();
      expect(res.status).not.toHaveBeenCalled();
      expect(res.json).not.toHaveBeenCalled();
    });

    test('dovrebbe rifiutare una richiesta senza token', () => {
      // Arrange
      const req = { headers: {} };
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      const next = jest.fn();

      // Act
      verifyToken(req, res, next);

      // Assert
      expect(jwt.verify).not.toHaveBeenCalled();
      expect(next).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({ message: 'Token di autenticazione non fornito' });
    });

    test('dovrebbe rifiutare un token non valido', () => {
      // Arrange
      const req = {
        headers: {
          authorization: 'Bearer invalid-token'
        }
      };
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      const next = jest.fn();
      
      jwt.verify.mockImplementation((token, secret, callback) => {
        callback(new Error('Token non valido'), null);
      });

      // Act
      verifyToken(req, res, next);

      // Assert
      expect(jwt.verify).toHaveBeenCalled();
      expect(next).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({ message: 'Token non valido o scaduto' });
    });
  });

  describe('checkRole', () => {
    test('dovrebbe permettere l\'accesso a un utente con ruolo autorizzato', () => {
      // Arrange
      const roles = ['admin', 'operator'];
      const req = {
        user: { role: 'operator' }
      };
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      const next = jest.fn();

      // Act
      const middleware = checkRole(roles);
      middleware(req, res, next);

      // Assert
      expect(next).toHaveBeenCalled();
      expect(res.status).not.toHaveBeenCalled();
      expect(res.json).not.toHaveBeenCalled();
    });

    test('dovrebbe negare l\'accesso a un utente con ruolo non autorizzato', () => {
      // Arrange
      const roles = ['admin', 'operator'];
      const req = {
        user: { role: 'client' }
      };
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      const next = jest.fn();

      // Act
      const middleware = checkRole(roles);
      middleware(req, res, next);

      // Assert
      expect(next).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({ message: 'Accesso negato: ruolo non autorizzato' });
    });
  });
});
