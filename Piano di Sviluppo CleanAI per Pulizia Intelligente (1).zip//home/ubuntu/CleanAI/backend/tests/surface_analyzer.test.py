// File: backend/tests/surface_analyzer.test.py
import unittest
from unittest.mock import patch, MagicMock
import numpy as np
import torch
from src.surface_analyzer import SurfaceAnalyzer

class TestSurfaceAnalyzer(unittest.TestCase):
    def setUp(self):
        # Crea un'istanza di SurfaceAnalyzer con modello mockato
        with patch('src.surface_analyzer.YOLO'):
            self.analyzer = SurfaceAnalyzer(model_path='mock_path')
            self.analyzer.model = MagicMock()
    
    def test_load_model(self):
        # Test del caricamento del modello
        with patch('src.surface_analyzer.YOLO') as mock_yolo:
            mock_model = MagicMock()
            mock_yolo.return_value = mock_model
            
            analyzer = SurfaceAnalyzer(model_path='test_path')
            
            mock_yolo.assert_called_once_with('test_path')
            self.assertEqual(analyzer.model, mock_model)
    
    def test_preprocess_image(self):
        # Test del preprocessamento dell'immagine
        mock_image = MagicMock()
        mock_image.shape = (480, 640, 3)
        
        result = self.analyzer._preprocess_image(mock_image)
        
        # Verifica che l'immagine sia stata ridimensionata
        self.assertEqual(result.shape, (480, 640, 3))
    
    @patch('src.surface_analyzer.cv2.imread')
    def test_load_image(self, mock_imread):
        # Test del caricamento dell'immagine
        mock_image = MagicMock()
        mock_imread.return_value = mock_image
        
        result = self.analyzer.load_image('test_image.jpg')
        
        mock_imread.assert_called_once_with('test_image.jpg')
        self.assertEqual(result, mock_image)
    
    @patch('src.surface_analyzer.cv2.imread')
    def test_load_image_error(self, mock_imread):
        # Test del caricamento dell'immagine con errore
        mock_imread.return_value = None
        
        with self.assertRaises(ValueError):
            self.analyzer.load_image('nonexistent_image.jpg')
    
    def test_analyze_surface(self):
        # Test dell'analisi della superficie
        mock_image = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Mock della risposta del modello
        mock_results = MagicMock()
        mock_results.xyxy = [torch.tensor([[100, 100, 200, 200, 0.9, 1]])]  # x1, y1, x2, y2, conf, class
        self.analyzer.model.return_value = mock_results
        
        result = self.analyzer.analyze_surface(mock_image)
        
        # Verifica che il modello sia stato chiamato
        self.analyzer.model.assert_called_once()
        
        # Verifica che il risultato contenga i campi attesi
        self.assertIn('dirt_detected', result)
        self.assertIn('cleanliness_score', result)
        self.assertIn('detected_objects', result)
        
        # Verifica che il punteggio di pulizia sia nel range corretto
        self.assertGreaterEqual(result['cleanliness_score'], 0.0)
        self.assertLessEqual(result['cleanliness_score'], 1.0)
    
    def test_compare_before_after(self):
        # Test del confronto prima/dopo
        before_result = {
            'dirt_detected': True,
            'cleanliness_score': 0.5,
            'detected_objects': [{'class': 'dirt', 'confidence': 0.9, 'box': [100, 100, 200, 200]}]
        }
        
        after_result = {
            'dirt_detected': False,
            'cleanliness_score': 0.9,
            'detected_objects': []
        }
        
        result = self.analyzer.compare_before_after(before_result, after_result)
        
        # Verifica che il risultato contenga i campi attesi
        self.assertIn('improvement_score', result)
        self.assertIn('percentage_improvement', result)
        self.assertIn('quality_rating', result)
        
        # Verifica che il miglioramento sia calcolato correttamente
        self.assertEqual(result['improvement_score'], 0.4)
        self.assertEqual(result['percentage_improvement'], 80.0)
        
        # Verifica che il rating di qualità sia corretto
        self.assertEqual(result['quality_rating'], 'excellent')
    
    def test_generate_report(self):
        # Test della generazione del report
        before_image = np.zeros((480, 640, 3), dtype=np.uint8)
        after_image = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Mock dei risultati dell'analisi
        before_result = {
            'dirt_detected': True,
            'cleanliness_score': 0.5,
            'detected_objects': [{'class': 'dirt', 'confidence': 0.9, 'box': [100, 100, 200, 200]}]
        }
        
        after_result = {
            'dirt_detected': False,
            'cleanliness_score': 0.9,
            'detected_objects': []
        }
        
        comparison = {
            'improvement_score': 0.4,
            'percentage_improvement': 80.0,
            'quality_rating': 'excellent'
        }
        
        with patch.object(self.analyzer, 'analyze_surface') as mock_analyze:
            mock_analyze.side_effect = [before_result, after_result]
            
            with patch.object(self.analyzer, 'compare_before_after') as mock_compare:
                mock_compare.return_value = comparison
                
                report = self.analyzer.generate_report(before_image, after_image)
                
                # Verifica che il report contenga i campi attesi
                self.assertIn('before_analysis', report)
                self.assertIn('after_analysis', report)
                self.assertIn('comparison', report)
                self.assertIn('timestamp', report)
                
                # Verifica che i metodi siano stati chiamati correttamente
                mock_analyze.assert_any_call(before_image)
                mock_analyze.assert_any_call(after_image)
                mock_compare.assert_called_once_with(before_result, after_result)

if __name__ == '__main__':
    unittest.main()
