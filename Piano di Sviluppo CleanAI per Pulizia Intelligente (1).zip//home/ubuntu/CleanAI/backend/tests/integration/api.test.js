// File: backend/tests/integration/api.test.js
const request = require('supertest');
const { app } = require('../../src/main');
const { supabase } = require('../../src/supabase-config');

describe('API Integration Tests', () => {
  let authToken;
  let taskId;

  // Prima di tutti i test, effettua il login per ottenere un token
  beforeAll(async () => {
    // Mock del login per ottenere un token di autenticazione
    const loginResponse = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });
    
    authToken = loginResponse.body.token;
  });

  describe('Tasks API Flow', () => {
    test('Dovrebbe creare, leggere, aggiornare ed eliminare un\'attività', async () => {
      // 1. Crea una nuova attività
      const newTask = {
        title: 'Test Integration Task',
        description: 'Task creato per test di integrazione',
        status: 'pending',
        location: 'Area Test',
        assigned_to: 'operator_1'
      };
      
      const createResponse = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send(newTask);
      
      expect(createResponse.status).toBe(201);
      expect(createResponse.body).toHaveProperty('id');
      expect(createResponse.body.title).toBe(newTask.title);
      
      taskId = createResponse.body.id;
      
      // 2. Leggi l'attività creata
      const getResponse = await request(app)
        .get(`/api/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(getResponse.status).toBe(200);
      expect(getResponse.body.id).toBe(taskId);
      expect(getResponse.body.title).toBe(newTask.title);
      
      // 3. Aggiorna l'attività
      const updateData = {
        status: 'in_progress',
        notes: 'Attività in corso'
      };
      
      const updateResponse = await request(app)
        .put(`/api/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateData);
      
      expect(updateResponse.status).toBe(200);
      expect(updateResponse.body.status).toBe(updateData.status);
      expect(updateResponse.body.notes).toBe(updateData.notes);
      
      // 4. Verifica che l'aggiornamento sia stato applicato
      const getUpdatedResponse = await request(app)
        .get(`/api/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(getUpdatedResponse.status).toBe(200);
      expect(getUpdatedResponse.body.status).toBe(updateData.status);
      
      // 5. Elimina l'attività
      const deleteResponse = await request(app)
        .delete(`/api/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(deleteResponse.status).toBe(200);
      expect(deleteResponse.body).toHaveProperty('message', 'Task deleted successfully');
      
      // 6. Verifica che l'attività sia stata eliminata
      const getDeletedResponse = await request(app)
        .get(`/api/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(getDeletedResponse.status).toBe(404);
    });
  });

  describe('Quality Analysis Flow', () => {
    test('Dovrebbe analizzare immagini e salvare i risultati', async () => {
      // 1. Carica un'immagine "prima"
      const beforeUploadResponse = await request(app)
        .post('/api/analysis/upload')
        .set('Authorization', `Bearer ${authToken}`)
        .attach('image', 'tests/fixtures/before_image.jpg');
      
      expect(beforeUploadResponse.status).toBe(200);
      expect(beforeUploadResponse.body).toHaveProperty('imageUrl');
      
      const beforeImageUrl = beforeUploadResponse.body.imageUrl;
      
      // 2. Carica un'immagine "dopo"
      const afterUploadResponse = await request(app)
        .post('/api/analysis/upload')
        .set('Authorization', `Bearer ${authToken}`)
        .attach('image', 'tests/fixtures/after_image.jpg');
      
      expect(afterUploadResponse.status).toBe(200);
      expect(afterUploadResponse.body).toHaveProperty('imageUrl');
      
      const afterImageUrl = afterUploadResponse.body.imageUrl;
      
      // 3. Analizza le immagini
      const analysisResponse = await request(app)
        .post('/api/analysis/compare')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          beforeImageUrl,
          afterImageUrl,
          taskId: 123,
          location: 'Test Area'
        });
      
      expect(analysisResponse.status).toBe(200);
      expect(analysisResponse.body).toHaveProperty('report');
      expect(analysisResponse.body.report).toHaveProperty('comparison');
      expect(analysisResponse.body.report.comparison).toHaveProperty('improvement_score');
      
      const reportId = analysisResponse.body.reportId;
      
      // 4. Ottieni il report salvato
      const getReportResponse = await request(app)
        .get(`/api/analysis/reports/${reportId}`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(getReportResponse.status).toBe(200);
      expect(getReportResponse.body).toHaveProperty('id', reportId);
      expect(getReportResponse.body).toHaveProperty('report');
    });
  });

  describe('Notification System Flow', () => {
    test('Dovrebbe inviare e ricevere notifiche', async () => {
      // 1. Invia una notifica
      const notificationData = {
        title: 'Test Notification',
        message: 'Questa è una notifica di test',
        recipientId: 'operator_1',
        priority: 'high'
      };
      
      const sendResponse = await request(app)
        .post('/api/notifications/send')
        .set('Authorization', `Bearer ${authToken}`)
        .send(notificationData);
      
      expect(sendResponse.status).toBe(200);
      expect(sendResponse.body).toHaveProperty('success', true);
      expect(sendResponse.body).toHaveProperty('notificationId');
      
      const notificationId = sendResponse.body.notificationId;
      
      // 2. Ottieni le notifiche dell'utente
      const getNotificationsResponse = await request(app)
        .get('/api/notifications')
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(getNotificationsResponse.status).toBe(200);
      expect(getNotificationsResponse.body).toBeInstanceOf(Array);
      
      // Trova la notifica inviata
      const sentNotification = getNotificationsResponse.body.find(n => n.id === notificationId);
      expect(sentNotification).toBeDefined();
      expect(sentNotification.title).toBe(notificationData.title);
      
      // 3. Segna la notifica come letta
      const markReadResponse = await request(app)
        .put(`/api/notifications/${notificationId}/read`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(markReadResponse.status).toBe(200);
      expect(markReadResponse.body).toHaveProperty('success', true);
      
      // 4. Verifica che la notifica sia stata segnata come letta
      const getUpdatedNotificationsResponse = await request(app)
        .get('/api/notifications')
        .set('Authorization', `Bearer ${authToken}`);
      
      const updatedNotification = getUpdatedNotificationsResponse.body.find(n => n.id === notificationId);
      expect(updatedNotification).toBeDefined();
      expect(updatedNotification.read).toBe(true);
    });
  });
});
