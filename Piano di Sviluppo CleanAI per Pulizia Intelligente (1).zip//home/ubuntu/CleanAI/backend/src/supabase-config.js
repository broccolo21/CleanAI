// Configurazione Supabase per CleanAI
import { createClient } from '@supabase/supabase-js';

// Queste variabili dovrebbero essere sostituite con valori reali in produzione
// e gestite tramite variabili d'ambiente
const supabaseUrl = process.env.SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'your-supabase-anon-key';

// Creazione del client Supabase
export const supabase = createClient(supabaseUrl, supabaseKey);

// Definizione delle tabelle principali
/*
Tabelle principali nel database:

1. users - Utenti del sistema (operatori, supervisori, amministratori)
2. clients - Clienti che richiedono servizi di pulizia
3. locations - Luoghi dove vengono effettuate le pulizie
4. cleaning_tasks - Attività di pulizia programmate
5. cleaning_reports - Report delle pulizie effettuate
6. iot_sensors - Sensori IoT installati nelle location
7. sensor_readings - Letture dei sensori IoT
8. notifications - Notifiche inviate agli utenti
*/

// Funzioni di utilità per interagire con Supabase
export const supabaseUtils = {
  // Autenticazione
  auth: {
    signUp: async (email, password) => {
      return await supabase.auth.signUp({ email, password });
    },
    signIn: async (email, password) => {
      return await supabase.auth.signInWithPassword({ email, password });
    },
    signOut: async () => {
      return await supabase.auth.signOut();
    },
    getUser: async () => {
      return await supabase.auth.getUser();
    }
  },
  
  // Operazioni CRUD per le tabelle principali
  users: {
    getAll: async () => {
      return await supabase.from('users').select('*');
    },
    getById: async (id) => {
      return await supabase.from('users').select('*').eq('id', id).single();
    },
    create: async (userData) => {
      return await supabase.from('users').insert(userData);
    },
    update: async (id, userData) => {
      return await supabase.from('users').update(userData).eq('id', id);
    },
    delete: async (id) => {
      return await supabase.from('users').delete().eq('id', id);
    }
  },
  
  // Altre tabelle seguono lo stesso pattern...
  
  // Funzioni specifiche per CleanAI
  cleaningTasks: {
    getTasksForOperator: async (operatorId) => {
      return await supabase
        .from('cleaning_tasks')
        .select('*, locations(*)')
        .eq('operator_id', operatorId)
        .order('scheduled_at', { ascending: true });
    },
    
    updateTaskStatus: async (taskId, status, completionData = {}) => {
      return await supabase
        .from('cleaning_tasks')
        .update({ 
          status, 
          completed_at: status === 'completed' ? new Date() : null,
          ...completionData 
        })
        .eq('id', taskId);
    },
    
    createCleaningReport: async (reportData) => {
      return await supabase
        .from('cleaning_reports')
        .insert(reportData);
    }
  },
  
  // Funzioni per i sensori IoT
  iotSensors: {
    getLatestReadings: async (locationId) => {
      return await supabase
        .from('sensor_readings')
        .select('*, iot_sensors(*)')
        .eq('location_id', locationId)
        .order('timestamp', { ascending: false })
        .limit(10);
    },
    
    createSensorReading: async (readingData) => {
      return await supabase
        .from('sensor_readings')
        .insert(readingData);
    }
  }
};

export default supabaseUtils;
