// File: frontend/src/components/__tests__/BeforeAfterAnalysis.test.js
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import BeforeAfterAnalysis from '../BeforeAfterAnalysis';

// Mock di TensorflowIntegration
jest.mock('../TensorflowIntegration', () => {
  return jest.fn(({ imageUrl, onPrediction }) => {
    // Simula la predizione dopo il rendering
    React.useEffect(() => {
      if (imageUrl && onPrediction) {
        setTimeout(() => {
          onPrediction({
            cleanlinessScore: {
              arraySync: () => imageUrl.includes('before') ? 0.5 : 0.9
            }
          });
        }, 100);
      }
    }, [imageUrl, onPrediction]);
    
    return <div data-testid="tensorflow-integration">TensorFlow Integration Mock</div>;
  });
});

describe('BeforeAfterAnalysis Component', () => {
  const mockOnAnalysisComplete = jest.fn();
  
  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock per FileReader
    global.FileReader = function() {
      this.readAsDataURL = jest.fn();
      setTimeout(() => {
        this.onload({ target: { result: 'data:image/jpeg;base64,mockImageData' } });
      }, 50);
    };
  });
  
  test('dovrebbe renderizzare correttamente il componente', () => {
    render(<BeforeAfterAnalysis onAnalysisComplete={mockOnAnalysisComplete} />);
    
    expect(screen.getByText('Analisi Visiva Prima/Dopo')).toBeInTheDocument();
    expect(screen.getByText('Prima della Pulizia')).toBeInTheDocument();
    expect(screen.getByText('Dopo la Pulizia')).toBeInTheDocument();
  });
  
  test('dovrebbe gestire il caricamento delle immagini', async () => {
    render(<BeforeAfterAnalysis onAnalysisComplete={mockOnAnalysisComplete} />);
    
    // Simula il caricamento dell'immagine "prima"
    const beforeInput = screen.getByLabelText('Carica immagine "prima"');
    const beforeFile = new File(['before'], 'before.jpg', { type: 'image/jpeg' });
    fireEvent.change(beforeInput, { target: { files: [beforeFile] } });
    
    // Simula il caricamento dell'immagine "dopo"
    const afterInput = screen.getByLabelText('Carica immagine "dopo"');
    const afterFile = new File(['after'], 'after.jpg', { type: 'image/jpeg' });
    fireEvent.change(afterInput, { target: { files: [afterFile] } });
    
    // Verifica che TensorflowIntegration sia stato renderizzato per entrambe le immagini
    await waitFor(() => {
      expect(screen.getAllByTestId('tensorflow-integration')).toHaveLength(2);
    });
  });
  
  test('dovrebbe mostrare i risultati dell\'analisi dopo il caricamento di entrambe le immagini', async () => {
    render(<BeforeAfterAnalysis onAnalysisComplete={mockOnAnalysisComplete} />);
    
    // Simula il caricamento dell'immagine "prima"
    const beforeInput = screen.getByLabelText('Carica immagine "prima"');
    const beforeFile = new File(['before'], 'before.jpg', { type: 'image/jpeg' });
    fireEvent.change(beforeInput, { target: { files: [beforeFile] } });
    
    // Simula il caricamento dell'immagine "dopo"
    const afterInput = screen.getByLabelText('Carica immagine "dopo"');
    const afterFile = new File(['after'], 'after.jpg', { type: 'image/jpeg' });
    fireEvent.change(afterInput, { target: { files: [afterFile] } });
    
    // Attendi che i risultati dell'analisi siano visualizzati
    await waitFor(() => {
      expect(screen.getByText('Risultati dell\'Analisi')).toBeInTheDocument();
    }, { timeout: 3000 });
    
    // Verifica che i punteggi siano visualizzati correttamente
    expect(screen.getByText('50.0%')).toBeInTheDocument(); // Punteggio Prima
    expect(screen.getByText('90.0%')).toBeInTheDocument(); // Punteggio Dopo
    expect(screen.getByText('+40.0%')).toBeInTheDocument(); // Miglioramento
    
    // Verifica che la valutazione sia visualizzata
    expect(screen.getByText(/Miglioramento/)).toBeInTheDocument();
    
    // Verifica che il callback onAnalysisComplete sia stato chiamato
    expect(mockOnAnalysisComplete).toHaveBeenCalledTimes(1);
    expect(mockOnAnalysisComplete).toHaveBeenCalledWith(expect.objectContaining({
      beforeScore: 0.5,
      afterScore: 0.9,
      improvement: 0.4,
      improvementPercentage: 40
    }));
  });
  
  test('dovrebbe resettare l\'analisi quando si clicca su "Nuova Analisi"', async () => {
    render(<BeforeAfterAnalysis onAnalysisComplete={mockOnAnalysisComplete} />);
    
    // Simula il caricamento delle immagini e attendi i risultati
    const beforeInput = screen.getByLabelText('Carica immagine "prima"');
    const afterInput = screen.getByLabelText('Carica immagine "dopo"');
    
    fireEvent.change(beforeInput, { target: { files: [new File(['before'], 'before.jpg', { type: 'image/jpeg' })] } });
    fireEvent.change(afterInput, { target: { files: [new File(['after'], 'after.jpg', { type: 'image/jpeg' })] } });
    
    // Attendi che i risultati dell'analisi siano visualizzati
    await waitFor(() => {
      expect(screen.getByText('Risultati dell\'Analisi')).toBeInTheDocument();
    }, { timeout: 3000 });
    
    // Clicca sul pulsante "Nuova Analisi"
    const resetButton = screen.getByText('Nuova Analisi');
    fireEvent.click(resetButton);
    
    // Verifica che i risultati non siano più visualizzati
    await waitFor(() => {
      expect(screen.queryByText('Risultati dell\'Analisi')).not.toBeInTheDocument();
    });
  });
  
  test('dovrebbe simulare il salvataggio dei risultati', async () => {
    // Mock di console.log
    const originalConsoleLog = console.log;
    console.log = jest.fn();
    
    render(<BeforeAfterAnalysis onAnalysisComplete={mockOnAnalysisComplete} />);
    
    // Simula il caricamento delle immagini e attendi i risultati
    const beforeInput = screen.getByLabelText('Carica immagine "prima"');
    const afterInput = screen.getByLabelText('Carica immagine "dopo"');
    
    fireEvent.change(beforeInput, { target: { files: [new File(['before'], 'before.jpg', { type: 'image/jpeg' })] } });
    fireEvent.change(afterInput, { target: { files: [new File(['after'], 'after.jpg', { type: 'image/jpeg' })] } });
    
    // Attendi che i risultati dell'analisi siano visualizzati
    await waitFor(() => {
      expect(screen.getByText('Risultati dell\'Analisi')).toBeInTheDocument();
    }, { timeout: 3000 });
    
    // Clicca sul pulsante "Salva Risultati"
    const saveButton = screen.getByText('Salva Risultati');
    fireEvent.click(saveButton);
    
    // Attendi che il salvataggio sia completato
    await waitFor(() => {
      expect(console.log).toHaveBeenCalledWith('Risultati salvati con successo');
    });
    
    // Verifica che i risultati non siano più visualizzati (reset dopo salvataggio)
    await waitFor(() => {
      expect(screen.queryByText('Risultati dell\'Analisi')).not.toBeInTheDocument();
    });
    
    // Ripristina console.log
    console.log = originalConsoleLog;
  });
});
