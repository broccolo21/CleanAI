// File: frontend/src/components/__tests__/NotificationSystem.test.js
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import NotificationSystem from '../NotificationSystem';

// Mock dei moduli esterni
jest.mock('../../utils/firebase-config', () => ({
  createNotificationManager: jest.fn().mockReturnValue({
    initialize: jest.fn().mockResolvedValue(true),
    subscribeToTopic: jest.fn().mockResolvedValue(true),
    cleanup: jest.fn()
  })
}));

jest.mock('../../utils/websocket-service', () => ({
  getWebSocketService: jest.fn().mockReturnValue({
    connect: jest.fn().mockResolvedValue(true),
    disconnect: jest.fn(),
    on: jest.fn(),
    isConnected: jest.fn().mockReturnValue(true)
  })
}));

describe('NotificationSystem Component', () => {
  const mockProps = {
    userType: 'operator',
    userId: '123',
    authToken: 'mock-token'
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('dovrebbe renderizzare il pulsante delle notifiche', () => {
    render(<NotificationSystem {...mockProps} />);
    
    // Verifica che il pulsante delle notifiche sia presente
    const notificationButton = screen.getByLabelText('Notifiche');
    expect(notificationButton).toBeInTheDocument();
  });

  test('dovrebbe mostrare il pannello delle notifiche quando si clicca sul pulsante', async () => {
    render(<NotificationSystem {...mockProps} />);
    
    // Clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText('Notifiche');
    fireEvent.click(notificationButton);
    
    // Verifica che il pannello delle notifiche sia visibile
    const notificationPanel = await screen.findByText('Notifiche');
    expect(notificationPanel).toBeInTheDocument();
  });

  test('dovrebbe mostrare un messaggio quando non ci sono notifiche', async () => {
    // Sovrascrivi l'implementazione di loadInitialNotifications per restituire un array vuoto
    jest.spyOn(global, 'setTimeout').mockImplementationOnce((cb) => {
      cb();
      return 999;
    });
    
    render(<NotificationSystem {...mockProps} />);
    
    // Clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText('Notifiche');
    fireEvent.click(notificationButton);
    
    // Verifica che il messaggio "Nessuna notifica" sia visibile
    const emptyMessage = await screen.findByText('Nessuna notifica da visualizzare');
    expect(emptyMessage).toBeInTheDocument();
  });

  test('dovrebbe mostrare il badge con il conteggio delle notifiche non lette', async () => {
    // Sovrascrivi l'implementazione per simulare notifiche non lette
    jest.spyOn(global, 'setTimeout').mockImplementationOnce((cb) => {
      cb();
      return 999;
    });
    
    render(<NotificationSystem {...mockProps} />);
    
    // Verifica che il badge con il conteggio sia visibile
    const badge = await screen.findByText('1');
    expect(badge).toBeInTheDocument();
  });

  test('dovrebbe segnare una notifica come letta quando si clicca sul pulsante di spunta', async () => {
    render(<NotificationSystem {...mockProps} />);
    
    // Clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText('Notifiche');
    fireEvent.click(notificationButton);
    
    // Attendi che le notifiche siano caricate
    await waitFor(() => {
      expect(screen.queryByText('Allarme sensore')).toBeInTheDocument();
    });
    
    // Trova il pulsante di spunta e clicca su di esso
    const checkButton = screen.getAllByRole('button')[2]; // Il terzo pulsante dovrebbe essere quello di spunta
    fireEvent.click(checkButton);
    
    // Verifica che il badge sia stato aggiornato
    await waitFor(() => {
      expect(screen.queryByText('1')).not.toBeInTheDocument();
    });
  });

  test('dovrebbe eliminare una notifica quando si clicca sul pulsante di eliminazione', async () => {
    render(<NotificationSystem {...mockProps} />);
    
    // Clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText('Notifiche');
    fireEvent.click(notificationButton);
    
    // Attendi che le notifiche siano caricate
    await waitFor(() => {
      expect(screen.queryByText('Allarme sensore')).toBeInTheDocument();
    });
    
    // Trova il pulsante di eliminazione e clicca su di esso
    const deleteButton = screen.getAllByRole('button')[3]; // Il quarto pulsante dovrebbe essere quello di eliminazione
    fireEvent.click(deleteButton);
    
    // Verifica che la notifica sia stata eliminata
    await waitFor(() => {
      expect(screen.queryByText('Allarme sensore')).not.toBeInTheDocument();
    });
  });

  test('dovrebbe segnare tutte le notifiche come lette quando si clicca sul pulsante "Segna tutte come lette"', async () => {
    render(<NotificationSystem {...mockProps} />);
    
    // Clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText('Notifiche');
    fireEvent.click(notificationButton);
    
    // Attendi che le notifiche siano caricate
    await waitFor(() => {
      expect(screen.queryByText('Segna tutte come lette')).toBeInTheDocument();
    });
    
    // Trova il pulsante "Segna tutte come lette" e clicca su di esso
    const markAllButton = screen.getByText('Segna tutte come lette');
    fireEvent.click(markAllButton);
    
    // Verifica che il badge sia stato rimosso
    await waitFor(() => {
      expect(screen.queryByText('1')).not.toBeInTheDocument();
    });
  });
});
