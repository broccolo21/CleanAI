// File: frontend/tests/offline/offline.test.js
import { getOfflineStorage } from '../../src/utils/offline-storage';
import { openDB } from 'idb';

// Mock di openDB
jest.mock('idb', () => ({
  openDB: jest.fn().mockImplementation(() => ({
    put: jest.fn().mockResolvedValue(true),
    get: jest.fn().mockResolvedValue({ id: 1, title: 'Test Task' }),
    getAll: jest.fn().mockResolvedValue([
      { id: 1, title: 'Test Task 1' },
      { id: 2, title: 'Test Task 2' }
    ]),
    add: jest.fn().mockResolvedValue(1),
    delete: jest.fn().mockResolvedValue(true),
    clear: jest.fn().mockResolvedValue(true)
  }))
}));

// Mock di fetch
global.fetch = jest.fn().mockImplementation(() => 
  Promise.resolve({
    ok: true,
    json: () => Promise.resolve({ success: true }),
    text: () => Promise.resolve('Success')
  })
);

describe('OfflineStorage', () => {
  let offlineStorage;
  
  beforeEach(() => {
    // Ripulisci tutti i mock
    jest.clearAllMocks();
    
    // Mock di navigator.onLine
    Object.defineProperty(navigator, 'onLine', {
      configurable: true,
      value: true
    });
    
    // Ottieni l'istanza di OfflineStorage
    offlineStorage = getOfflineStorage();
  });
  
  test('dovrebbe inizializzare correttamente il database', async () => {
    expect(openDB).toHaveBeenCalled();
  });
  
  test('dovrebbe salvare un\'attività in locale', async () => {
    const task = { id: 1, title: 'Test Task', status: 'pending' };
    const result = await offlineStorage.saveTask(task);
    
    expect(result).toBe(true);
    const db = await openDB();
    expect(db.put).toHaveBeenCalledWith('tasks', task);
  });
  
  test('dovrebbe recuperare un\'attività dal database locale', async () => {
    const taskId = 1;
    const task = await offlineStorage.getTask(taskId);
    
    expect(task).toEqual({ id: 1, title: 'Test Task' });
    const db = await openDB();
    expect(db.get).toHaveBeenCalledWith('tasks', taskId);
  });
  
  test('dovrebbe recuperare tutte le attività dal database locale', async () => {
    const tasks = await offlineStorage.getAllTasks();
    
    expect(tasks).toHaveLength(2);
    expect(tasks[0].title).toBe('Test Task 1');
    expect(tasks[1].title).toBe('Test Task 2');
    
    const db = await openDB();
    expect(db.getAll).toHaveBeenCalledWith('tasks');
  });
  
  test('dovrebbe aggiungere una richiesta alla coda delle richieste in sospeso', async () => {
    const request = {
      url: 'https://api.example.com/tasks',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: { title: 'New Task' }
    };
    
    const result = await offlineStorage.addPendingRequest(request);
    
    expect(result).toBe(true);
    const db = await openDB();
    expect(db.add).toHaveBeenCalledWith('pending-requests', expect.objectContaining({
      url: request.url,
      method: request.method,
      headers: request.headers,
      body: request.body,
      timestamp: expect.any(String)
    }));
  });
  
  test('dovrebbe sincronizzare le richieste in sospeso quando si è online', async () => {
    // Mock di getPendingRequests
    jest.spyOn(offlineStorage, 'getPendingRequests').mockResolvedValue([
      { id: 1, url: 'https://api.example.com/tasks/1', method: 'PUT', body: { status: 'completed' }, timestamp: '2025-03-25T06:00:00.000Z' },
      { id: 2, url: 'https://api.example.com/tasks', method: 'POST', body: { title: 'New Task' }, timestamp: '2025-03-25T06:01:00.000Z' }
    ]);
    
    // Mock di removePendingRequest
    jest.spyOn(offlineStorage, 'removePendingRequest').mockResolvedValue(true);
    
    const result = await offlineStorage.syncPendingRequests();
    
    expect(result).toBe(true);
    expect(fetch).toHaveBeenCalledTimes(2);
    expect(offlineStorage.removePendingRequest).toHaveBeenCalledTimes(2);
  });
  
  test('dovrebbe gestire correttamente la modalità offline', async () => {
    // Simula la modalità offline
    Object.defineProperty(navigator, 'onLine', {
      configurable: true,
      value: false
    });
    
    // Forza l'aggiornamento dello stato online
    offlineStorage._handleOffline();
    
    // Mock di addPendingRequest
    jest.spyOn(offlineStorage, 'addPendingRequest').mockResolvedValue(true);
    
    const response = await offlineStorage.fetchWithOfflineSupport('https://api.example.com/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'New Task' })
    });
    
    const responseData = await response.json();
    
    expect(responseData).toEqual({
      success: true,
      offline: true,
      message: 'Richiesta salvata per la sincronizzazione'
    });
    
    expect(offlineStorage.addPendingRequest).toHaveBeenCalledWith(expect.objectContaining({
      url: 'https://api.example.com/tasks',
      method: 'POST'
    }));
  });
  
  test('dovrebbe gestire il passaggio tra modalità online e offline', async () => {
    // Inizialmente online
    expect(offlineStorage.isOnline).toBe(true);
    
    // Simula la perdita di connessione
    offlineStorage._handleOffline();
    expect(offlineStorage.isOnline).toBe(false);
    
    // Simula il ripristino della connessione
    jest.spyOn(offlineStorage, 'syncPendingRequests').mockResolvedValue(true);
    offlineStorage._handleOnline();
    
    expect(offlineStorage.isOnline).toBe(true);
    expect(offlineStorage.syncPendingRequests).toHaveBeenCalled();
  });
  
  test('dovrebbe pulire il database', async () => {
    const result = await offlineStorage.clearDatabase();
    
    expect(result).toBe(true);
    const db = await openDB();
    expect(db.clear).toHaveBeenCalledTimes(3);
  });
});
