// File: frontend/tests/integration/app.test.js
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import App from '../../src/App';
import { SupabaseProvider } from '../../src/contexts/SupabaseContext';

// Mock dei moduli esterni
jest.mock('../../src/utils/firebase-config', () => ({
  createNotificationManager: jest.fn().mockReturnValue({
    initialize: jest.fn().mockResolvedValue(true),
    subscribeToTopic: jest.fn().mockResolvedValue(true),
    cleanup: jest.fn()
  })
}));

jest.mock('../../src/utils/websocket-service', () => ({
  getWebSocketService: jest.fn().mockReturnValue({
    connect: jest.fn().mockResolvedValue(true),
    disconnect: jest.fn(),
    on: jest.fn(),
    isConnected: jest.fn().mockReturnValue(true)
  })
}));

// Mock di Supabase
jest.mock('@supabase/supabase-js', () => ({
  createClient: jest.fn(() => ({
    auth: {
      signIn: jest.fn().mockResolvedValue({ user: { id: '123', email: 'test@example.com' }, error: null }),
      signOut: jest.fn().mockResolvedValue({ error: null }),
      onAuthStateChange: jest.fn().mockImplementation((callback) => {
        callback('SIGNED_IN', { user: { id: '123', email: 'test@example.com' } });
        return { data: { subscription: { unsubscribe: jest.fn() } } };
      })
    },
    from: jest.fn().mockReturnThis(),
    select: jest.fn().mockReturnThis(),
    insert: jest.fn().mockReturnThis(),
    update: jest.fn().mockReturnThis(),
    delete: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    order: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
    then: jest.fn().mockImplementation((callback) => callback({ data: [], error: null }))
  }))
}));

describe('App Integration Tests', () => {
  beforeEach(() => {
    // Ripulisci tutti i mock
    jest.clearAllMocks();
  });

  test('Dovrebbe renderizzare l\'app e navigare tra le pagine', async () => {
    render(
      <BrowserRouter>
        <SupabaseProvider>
          <App />
        </SupabaseProvider>
      </BrowserRouter>
    );

    // Verifica che la pagina di login sia visualizzata inizialmente
    expect(screen.getByText(/Accedi a CleanAI/i)).toBeInTheDocument();

    // Simula il login
    const emailInput = screen.getByLabelText(/Email/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const loginButton = screen.getByRole('button', { name: /Accedi/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(loginButton);

    // Attendi che la dashboard sia caricata dopo il login
    await waitFor(() => {
      expect(screen.getByText(/Dashboard/i)).toBeInTheDocument();
    });

    // Naviga alla pagina delle attività
    const tasksLink = screen.getByText(/Attività/i);
    fireEvent.click(tasksLink);

    // Verifica che la pagina delle attività sia visualizzata
    await waitFor(() => {
      expect(screen.getByText(/Gestione Attività/i)).toBeInTheDocument();
    });

    // Naviga alla pagina dei report
    const reportsLink = screen.getByText(/Report/i);
    fireEvent.click(reportsLink);

    // Verifica che la pagina dei report sia visualizzata
    await waitFor(() => {
      expect(screen.getByText(/Analisi e Report/i)).toBeInTheDocument();
    });

    // Naviga alla pagina delle impostazioni
    const settingsLink = screen.getByText(/Impostazioni/i);
    fireEvent.click(settingsLink);

    // Verifica che la pagina delle impostazioni sia visualizzata
    await waitFor(() => {
      expect(screen.getByText(/Impostazioni Utente/i)).toBeInTheDocument();
    });

    // Simula il logout
    const userMenu = screen.getByText(/test@example.com/i);
    fireEvent.click(userMenu);

    const logoutButton = screen.getByText(/Logout/i);
    fireEvent.click(logoutButton);

    // Verifica che l'utente sia tornato alla pagina di login
    await waitFor(() => {
      expect(screen.getByText(/Accedi a CleanAI/i)).toBeInTheDocument();
    });
  });

  test('Dovrebbe mostrare e interagire con il sistema di notifiche', async () => {
    render(
      <BrowserRouter>
        <SupabaseProvider>
          <App />
        </SupabaseProvider>
      </BrowserRouter>
    );

    // Simula il login
    const emailInput = screen.getByLabelText(/Email/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const loginButton = screen.getByRole('button', { name: /Accedi/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(loginButton);

    // Attendi che la dashboard sia caricata dopo il login
    await waitFor(() => {
      expect(screen.getByText(/Dashboard/i)).toBeInTheDocument();
    });

    // Trova e clicca sul pulsante delle notifiche
    const notificationButton = screen.getByLabelText(/Notifiche/i);
    fireEvent.click(notificationButton);

    // Verifica che il pannello delle notifiche sia visualizzato
    await waitFor(() => {
      expect(screen.getByText(/Notifiche/i)).toBeInTheDocument();
    });

    // Verifica che lo stato della connessione sia visualizzato
    expect(screen.getByText(/Connesso/i)).toBeInTheDocument();

    // Chiudi il pannello delle notifiche cliccando altrove
    fireEvent.click(screen.getByText(/Dashboard/i));

    // Verifica che il pannello delle notifiche sia stato chiuso
    await waitFor(() => {
      expect(screen.queryByText(/Segna tutte come lette/i)).not.toBeInTheDocument();
    });
  });

  test('Dovrebbe visualizzare e interagire con i grafici della dashboard', async () => {
    render(
      <BrowserRouter>
        <SupabaseProvider>
          <App />
        </SupabaseProvider>
      </BrowserRouter>
    );

    // Simula il login
    const emailInput = screen.getByLabelText(/Email/i);
    const passwordInput = screen.getByLabelText(/Password/i);
    const loginButton = screen.getByRole('button', { name: /Accedi/i });

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.change(passwordInput, { target: { value: 'password123' } });
    fireEvent.click(loginButton);

    // Attendi che la dashboard sia caricata dopo il login
    await waitFor(() => {
      expect(screen.getByText(/Dashboard/i)).toBeInTheDocument();
    });

    // Verifica che le statistiche principali siano visualizzate
    expect(screen.getByText(/Attività Completate/i)).toBeInTheDocument();
    expect(screen.getByText(/Punteggio Qualità/i)).toBeInTheDocument();
    expect(screen.getByText(/Sensori Attivi/i)).toBeInTheDocument();

    // Verifica che i grafici siano visualizzati
    expect(screen.getByText(/Andamento Attività/i)).toBeInTheDocument();
    expect(screen.getByText(/Punteggi Qualità/i)).toBeInTheDocument();

    // Verifica che la lista delle attività recenti sia visualizzata
    expect(screen.getByText(/Attività Recenti/i)).toBeInTheDocument();

    // Cambia il periodo di visualizzazione dei dati
    const periodSelector = screen.getByLabelText(/Periodo/i);
    fireEvent.change(periodSelector, { target: { value: 'month' } });

    // Verifica che i dati siano stati aggiornati (in un'implementazione reale)
    // Qui possiamo solo verificare che il selettore sia stato cambiato
    expect(periodSelector.value).toBe('month');
  });
});
