# Analisi dei Requisiti - CleanAI

## 1. Panoramica del Progetto

CleanAI è un sistema avanzato che ottimizza la gestione operativa delle imprese di pulizie attraverso l'intelligenza artificiale. Il sistema offre funzionalità di guida per gli operatori tramite un tutor virtuale, analisi della qualità della pulizia con visione artificiale, e si integra con IoT e Machine Learning per un'ottimizzazione dinamica delle operazioni.

## 2. Stack Tecnologico

### Backend
- Node.js con NestJS
- Python FastAPI
- Supabase (PostgreSQL con Edge Functions)

### Frontend
- React.js + TailwindCSS (WebApp)
- React Native (Mobile)
- Supporto PWA per funzionamento offline

### AI e Machine Learning
- TensorFlow.js
- PyTorch
- OpenAI API
- YOLO-NAS per analisi superfici

### IoT & Sensori
- MQTT Broker per monitoraggio ambientale

### Notifiche
- Firebase Cloud Messaging
- WebSocket Live Updates

### Deploy
- Docker
- Kubernetes
- Vercel

## 3. Funzionalità Principali

### 3.1. Tutor Virtuale per Operatori
- **Obiettivo**: Fornire istruzioni vocali e visive per il personale
- **Tecnologia**: OpenAI GPT + React Native
- **Funzionamento**: L'operatore riceve step di pulizia personalizzati via smartwatch o auricolare

### 3.2. Analisi Visiva della Pulizia
- **Obiettivo**: Certificare la qualità delle pulizie
- **Tecnologia**: YOLO-NAS + TensorFlow.js
- **Funzionamento**: Foto prima/dopo analizzate da AI per valutare il livello di pulizia

### 3.3. Dashboard con KPI e Report
- **Obiettivo**: Monitorare le operazioni in tempo reale
- **Tecnologia**: React.js + Supabase + GraphQL API
- **Funzionamento**: Mostra percentuali di completamento, tempi medi e anomalie

### 3.4. Ottimizzazione Operativa con AI
- **Obiettivo**: Ridurre sprechi e migliorare l'efficienza
- **Tecnologia**: PyTorch + Data Analysis
- **Funzionamento**: L'AI raccoglie dati e prevede quando e dove intervenire

### 3.5. IoT per Pulizie Predittive
- **Obiettivo**: Interventi attivati da dati in tempo reale
- **Tecnologia**: Sensori IoT + MQTT + AWS Lambda
- **Funzionamento**: Se il livello di sporco è alto, CleanAI avvisa il personale

### 3.6. Notifiche Intelligenti
- **Obiettivo**: Mantenere clienti e dipendenti aggiornati
- **Tecnologia**: Firebase Cloud Messaging + WebSocket
- **Funzionamento**: Notifiche su richieste, appuntamenti e premi per operatori

## 4. Requisiti Aggiuntivi (basati sulle preferenze tecnologiche)

- Implementazione di Next.js (React 18) per il frontend
- Sistema di autenticazione con Supabase
- Supporto PWA per funzionalità offline
- Integrazione con LangChain per funzionalità AI
- Hosting su Vercel (frontend) e Railway/Fly.io (backend)
- CI/CD con GitHub Actions
- Dashboard operativa con sistema di checklist digitale
- Gestione documenti e fatturazione
- Modalità chiaro/scuro
- Accessibilità migliorata
- Notifiche push/email

## 5. Priorità per MVP

1. Tutor Virtuale per Operatori
2. Analisi Visiva della Pulizia
3. Dashboard con KPI e Report
4. Notifiche Intelligenti
5. Ottimizzazione Operativa con AI
6. IoT per Pulizie Predittive
