# Architettura del Sistema - CleanAI

## Panoramica

CleanAI è un sistema avanzato che utilizza l'intelligenza artificiale, la visione artificiale e l'Internet of Things (IoT) per ottimizzare la gestione delle operazioni di pulizia professionale. Questa documentazione descrive l'architettura complessiva del sistema, i componenti principali e le loro interazioni.

## Architettura Generale

CleanAI segue un'architettura a microservizi, con componenti separati che comunicano tra loro tramite API RESTful e GraphQL. Il sistema è progettato per essere scalabile, resiliente e facilmente estensibile.

### Diagramma dell'Architettura

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Client Layer   │◄───►│  Service Layer  │◄───►│   Data Layer    │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        ▲                       ▲                       ▲
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│    AI Layer     │◄───►│    IoT Layer    │◄───►│ Integration Layer│
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

## Componenti Principali

### 1. Client Layer

Il Client Layer comprende le interfacce utente attraverso le quali gli utenti interagiscono con il sistema.

#### 1.1 Web Application (React.js + TailwindCSS)

- **Dashboard**: Visualizzazione di KPI, grafici e report
- **Task Management**: Gestione delle attività di pulizia
- **Quality Analysis**: Visualizzazione dei risultati dell'analisi visiva
- **User Management**: Gestione degli utenti e dei ruoli
- **Settings**: Configurazione del sistema

#### 1.2 Mobile Application (React Native)

- **Operator Interface**: Interfaccia per gli operatori di pulizia
- **Virtual Tutor**: Assistente AI per guidare gli operatori
- **Camera Integration**: Acquisizione di immagini per l'analisi visiva
- **Offline Support**: Funzionalità offline con sincronizzazione
- **Push Notifications**: Notifiche in tempo reale

### 2. Service Layer

Il Service Layer contiene i servizi principali che implementano la logica di business del sistema.

#### 2.1 Backend API (Node.js con NestJS)

- **Authentication Service**: Gestione dell'autenticazione e autorizzazione
- **Task Service**: Gestione delle attività di pulizia
- **User Service**: Gestione degli utenti e dei ruoli
- **Notification Service**: Gestione delle notifiche
- **Report Service**: Generazione di report e analisi

#### 2.2 AI Service (Python con FastAPI)

- **Image Analysis Service**: Analisi delle immagini per valutare la qualità della pulizia
- **Virtual Tutor Service**: Generazione di istruzioni personalizzate per gli operatori
- **Optimization Service**: Ottimizzazione delle operazioni di pulizia
- **Prediction Service**: Previsione dei livelli di sporco e pianificazione proattiva

### 3. Data Layer

Il Data Layer gestisce la persistenza e l'accesso ai dati del sistema.

#### 3.1 Database (Supabase/PostgreSQL)

- **User Data**: Informazioni sugli utenti e ruoli
- **Task Data**: Dati sulle attività di pulizia
- **Quality Scores**: Punteggi di qualità delle pulizie
- **Sensor Data**: Dati provenienti dai sensori IoT
- **System Configuration**: Configurazione del sistema

#### 3.2 File Storage

- **Image Storage**: Archiviazione delle immagini per l'analisi visiva
- **Report Storage**: Archiviazione dei report generati
- **Backup Storage**: Backup dei dati del sistema

### 4. AI Layer

L'AI Layer implementa le funzionalità di intelligenza artificiale e machine learning del sistema.

#### 4.1 Computer Vision (YOLO-NAS)

- **Surface Analysis**: Analisi delle superfici per rilevare sporco e macchie
- **Before/After Comparison**: Confronto delle immagini prima e dopo la pulizia
- **Quality Assessment**: Valutazione della qualità della pulizia
- **Object Detection**: Rilevamento di oggetti e ostacoli

#### 4.2 Machine Learning (PyTorch)

- **Operational Optimization**: Ottimizzazione delle operazioni di pulizia
- **Resource Allocation**: Allocazione ottimale delle risorse
- **Predictive Maintenance**: Manutenzione predittiva delle attrezzature
- **Anomaly Detection**: Rilevamento di anomalie nelle operazioni

#### 4.3 Natural Language Processing (OpenAI API)

- **Virtual Tutor**: Generazione di istruzioni in linguaggio naturale
- **Query Understanding**: Comprensione delle query degli utenti
- **Report Generation**: Generazione di report in linguaggio naturale
- **Feedback Analysis**: Analisi del feedback degli utenti

### 5. IoT Layer

L'IoT Layer gestisce la comunicazione con i dispositivi IoT e l'elaborazione dei dati provenienti dai sensori.

#### 5.1 MQTT Broker

- **Sensor Communication**: Comunicazione con i sensori IoT
- **Data Collection**: Raccolta dei dati dai sensori
- **Command Distribution**: Distribuzione di comandi ai dispositivi
- **Status Monitoring**: Monitoraggio dello stato dei dispositivi

#### 5.2 Edge Computing

- **Local Data Processing**: Elaborazione locale dei dati
- **Bandwidth Optimization**: Ottimizzazione della larghezza di banda
- **Latency Reduction**: Riduzione della latenza
- **Offline Operation**: Funzionamento offline

### 6. Integration Layer

L'Integration Layer gestisce l'integrazione con sistemi esterni e servizi di terze parti.

#### 6.1 API Gateway

- **Request Routing**: Instradamento delle richieste ai servizi appropriati
- **Rate Limiting**: Limitazione della frequenza delle richieste
- **Authentication**: Autenticazione delle richieste
- **Logging**: Registrazione delle richieste e delle risposte

#### 6.2 External Integrations

- **Calendar Integration**: Integrazione con sistemi di calendario
- **ERP Integration**: Integrazione con sistemi ERP
- **CRM Integration**: Integrazione con sistemi CRM
- **Billing Integration**: Integrazione con sistemi di fatturazione

## Flussi di Dati Principali

### 1. Flusso di Analisi Visiva

1. L'operatore scatta foto prima e dopo la pulizia utilizzando l'app mobile
2. Le immagini vengono caricate sul server e archiviate nel File Storage
3. L'AI Service analizza le immagini utilizzando il modello YOLO-NAS
4. I risultati dell'analisi vengono salvati nel database
5. L'app mobile visualizza i risultati dell'analisi all'operatore
6. I report di qualità vengono generati e resi disponibili nella dashboard

### 2. Flusso del Tutor Virtuale

1. L'operatore seleziona un'attività nell'app mobile e avvia il Tutor Virtuale
2. L'app mobile invia una richiesta all'AI Service
3. L'AI Service genera istruzioni personalizzate utilizzando l'OpenAI API
4. Le istruzioni vengono inviate all'app mobile
5. L'app mobile presenta le istruzioni all'operatore tramite testo e voce
6. L'operatore conferma il completamento dei passaggi
7. I dati di completamento vengono salvati nel database

### 3. Flusso di Monitoraggio IoT

1. I sensori IoT raccolgono dati sull'ambiente (umidità, temperatura, livello di sporco, ecc.)
2. I dati vengono inviati al MQTT Broker
3. Il Broker inoltra i dati all'IoT Service
4. L'IoT Service elabora i dati e li salva nel database
5. Se vengono rilevate condizioni che richiedono attenzione, vengono generate notifiche
6. Le notifiche vengono inviate agli utenti appropriati tramite il Notification Service
7. I dati aggregati vengono visualizzati nella dashboard

## Tecnologie Utilizzate

### Frontend

- **React.js**: Framework JavaScript per lo sviluppo dell'interfaccia utente web
- **TailwindCSS**: Framework CSS per lo styling dell'interfaccia utente
- **React Native**: Framework per lo sviluppo dell'app mobile
- **TensorFlow.js**: Libreria per l'esecuzione di modelli di machine learning nel browser
- **Chart.js**: Libreria per la visualizzazione di grafici e dati
- **Apollo Client**: Client GraphQL per la comunicazione con il backend

### Backend

- **Node.js**: Ambiente di runtime JavaScript per il backend
- **NestJS**: Framework per lo sviluppo di applicazioni server-side scalabili
- **Python**: Linguaggio di programmazione per i servizi di AI e machine learning
- **FastAPI**: Framework Python per lo sviluppo di API ad alte prestazioni
- **Supabase**: Piattaforma open source per la gestione del database e delle autenticazioni
- **PostgreSQL**: Sistema di gestione di database relazionale
- **Redis**: Database in-memory per caching e messaggistica

### AI e Machine Learning

- **PyTorch**: Framework per lo sviluppo di modelli di machine learning
- **YOLO-NAS**: Modello di computer vision per l'analisi delle superfici
- **OpenAI API**: API per l'accesso a modelli di linguaggio avanzati
- **scikit-learn**: Libreria Python per il machine learning
- **TensorFlow**: Framework per lo sviluppo di modelli di machine learning

### IoT

- **MQTT**: Protocollo di messaggistica leggero per dispositivi IoT
- **Mosquitto**: Broker MQTT open source
- **AWS IoT Core**: Servizio cloud per la connessione di dispositivi IoT
- **Arduino**: Piattaforma per lo sviluppo di dispositivi IoT
- **Raspberry Pi**: Computer single-board per applicazioni IoT

### DevOps e Deployment

- **Docker**: Piattaforma per la containerizzazione delle applicazioni
- **Kubernetes**: Sistema per l'orchestrazione di container
- **Vercel**: Piattaforma per il deployment del frontend
- **Railway**: Piattaforma per il deployment del backend
- **GitHub Actions**: Sistema di CI/CD
- **Prometheus**: Sistema di monitoraggio
- **Grafana**: Piattaforma per la visualizzazione di metriche e log

## Sicurezza

### Autenticazione e Autorizzazione

- **JWT (JSON Web Tokens)**: Per l'autenticazione degli utenti
- **RBAC (Role-Based Access Control)**: Per il controllo degli accessi basato sui ruoli
- **OAuth 2.0**: Per l'autenticazione con provider esterni
- **2FA (Two-Factor Authentication)**: Per una maggiore sicurezza dell'accesso

### Protezione dei Dati

- **Crittografia dei dati in transito**: HTTPS/TLS
- **Crittografia dei dati a riposo**: AES-256
- **Hashing delle password**: bcrypt con salt
- **Sanitizzazione degli input**: Prevenzione di SQL injection e XSS

### Conformità

- **GDPR**: Conformità al Regolamento Generale sulla Protezione dei Dati
- **CCPA**: Conformità al California Consumer Privacy Act
- **ISO 27001**: Conformità agli standard di sicurezza delle informazioni
- **SOC 2**: Conformità ai principi di Trust Services

## Scalabilità e Prestazioni

### Strategie di Scalabilità

- **Scalabilità orizzontale**: Aggiunta di più istanze dei servizi
- **Scalabilità verticale**: Aumento delle risorse per le istanze esistenti
- **Auto-scaling**: Scalabilità automatica in base al carico
- **Sharding del database**: Distribuzione dei dati su più server

### Ottimizzazione delle Prestazioni

- **Caching**: Utilizzo di Redis per il caching dei dati frequentemente acceduti
- **CDN**: Utilizzo di Content Delivery Network per la distribuzione di contenuti statici
- **Lazy loading**: Caricamento differito di componenti e dati
- **Compressione**: Compressione dei dati per ridurre la larghezza di banda

## Monitoraggio e Logging

### Monitoraggio del Sistema

- **Prometheus**: Raccolta di metriche di sistema e applicazione
- **Grafana**: Visualizzazione delle metriche e creazione di dashboard
- **Alerting**: Configurazione di avvisi per condizioni anomale
- **Health checks**: Controlli periodici dello stato dei servizi

### Logging

- **ELK Stack**: Elasticsearch, Logstash e Kibana per la gestione dei log
- **Structured logging**: Log strutturati per una migliore analisi
- **Log rotation**: Rotazione dei file di log per gestire lo spazio su disco
- **Log aggregation**: Aggregazione dei log da tutti i servizi

## Disaster Recovery e Backup

### Strategie di Backup

- **Backup automatici**: Backup periodici del database e dei file
- **Backup incrementali**: Backup delle sole modifiche per risparmiare spazio
- **Backup geograficamente distribuiti**: Archiviazione dei backup in diverse regioni
- **Retention policy**: Politiche di conservazione dei backup

### Disaster Recovery

- **RTO (Recovery Time Objective)**: Tempo massimo accettabile per il ripristino del sistema
- **RPO (Recovery Point Objective)**: Quantità massima accettabile di perdita di dati
- **Failover automatico**: Passaggio automatico a sistemi di backup in caso di guasto
- **Procedure di ripristino**: Documentazione dettagliata delle procedure di ripristino

## Conclusione

L'architettura di CleanAI è progettata per essere robusta, scalabile e flessibile, consentendo al sistema di evolversi e adattarsi alle esigenze future. La separazione in layer e componenti ben definiti facilita la manutenzione e l'estensione del sistema, mentre l'utilizzo di tecnologie moderne garantisce prestazioni ottimali e un'esperienza utente di alta qualità.
